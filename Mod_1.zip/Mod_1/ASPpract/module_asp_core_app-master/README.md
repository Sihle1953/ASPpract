## ASP DOTNET CORE APP

### Description

This web application is an ASP.net core web app for learning ASP core concepts like MVC,Microservices,etc... It's still in progress !! 

### Features

It's gonna support the following features:

* MVC architecture
* Microservices with Ocealot
* API support
* Web security(Authentication,authorization)

### How to run

* Clone the repo
* If using Visual studio code
    :  File->Open folder and then 
    -> Terminal run : **dotnet run**
* If using Visual studio
    :  File ->Open folder and then run the app


